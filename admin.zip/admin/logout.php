
<?php
session_start();
session_unset($_SESSION['fname']);
session_destroy();
header('location:' .$adminurl.'/login.php');
?>

    
<?php

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "trp";
// $id     = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

$method = $_SERVER['REQUEST_METHOD'];
 
 
if ($conn) {
   //echo "Connection Successful";

} else {

  // echo "Connection Failed";
  die("Database connection failed" . mysqli_connect_error());

}



?>


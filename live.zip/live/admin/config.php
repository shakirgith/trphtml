<?php

$servername = "localhost";
$username   = "therainbowprint_therainb";
$password   = "therainb@200915T";
$dbname     = "therainbowprint_trp";
// $id     = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

$method = $_SERVER['REQUEST_METHOD'];
 
 
if ($conn) {
   //echo "Connection Successful";

} else {

  // echo "Connection Failed";
  die("Database connection failed" . mysqli_connect_error());

}



?>


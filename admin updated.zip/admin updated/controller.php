<?php
session_start();
include('config.php');
$adminurl = 'http://localhost/trphtml/admin';

$email = "";
$name = "";
// $errors = array();
$showError = '';


//if user signup button
// if(isset($_POST['signup'])){
//     $name = mysqli_real_escape_string($con, $_POST['name']);
//     $email = mysqli_real_escape_string($con, $_POST['email']);
//     $password = mysqli_real_escape_string($con, $_POST['password']);
//     $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
//     if($password !== $cpassword){
//         $errors['password'] = "Confirm password not matched!";
//     }
//     $email_check = "SELECT * FROM usertable WHERE email = '$email'";
//     $res = mysqli_query($con, $email_check);
//     if(mysqli_num_rows($res) > 0){
//         $errors['email'] = "Email that you have entered is already exist!";
//     }
//     if(count($errors) === 0){
//         $encpass = password_hash($password, PASSWORD_BCRYPT);
//         $code = rand(999999, 111111);
//         $status = "notverified";
//         $insert_data = "INSERT INTO usertable (name, email, password, code, status)
//                         values('$name', '$email', '$encpass', '$code', '$status')";
//         $data_check = mysqli_query($con, $insert_data);
//         if($data_check){
//             $subject = "Email Verification Code";
//             $message = "Your verification code is $code";
//             $sender = "From: shakir@webcontxt.com";
//             if(mail($email, $subject, $message, $sender)){
//                 $info = "We've sent a verification code to your email - $email";
//                 $_SESSION['info'] = $info;
//                 $_SESSION['email'] = $email;
//                 $_SESSION['password'] = $password;
//                 header('location: user-otp.php');
//                 exit();
//             }else{
//                 $errors['otp-error'] = "Failed while sending code!";
//             }
//         }else{
//             $errors['db-error'] = "Failed while inserting data into database!";
//         }
//     }

// }

//if user click continue button in forgot password form
if(isset($_POST['check-email'])) {

    $email = mysqli_real_escape_string($conn, $_POST['user_email']);
     $check_email = "SELECT * FROM admin_users WHERE user_email='$email'";
     $run_sql = mysqli_query($conn, $check_email);
 
         if(mysqli_num_rows($run_sql) > 0){
             $code = rand(999999, 111111);
             $insert_code = "UPDATE admin_users SET token = '$code' WHERE user_email = '$email'";
             $run_query =  mysqli_query($conn, $insert_code);
 
                 if($run_query){
                     $subject = "Password Reset Activation Code";
                     $message = "Your password reset code is $code";
                     $sender = "From: shakir@webcontxt.com";
                     if(mail($email, $subject, $message, $sender)){
                             $info = "We've sent a passwrod reset otp to your email - $email";
                             $_SESSION['info'] = $info;
                             $_SESSION['user_email'] = $email;
                             header('location: activation.php');
                             exit();
                     }else{
                         $showError = "Failed while sending code!";
                     }
 
             }else{
                $showError = "Something went wrong!";
            }
 
  }else{  
   $showError = "This email address does not exist!";
 }
}


 //if user click check reset otp button
if(isset($_POST['check-reset-otp'])){
    $_SESSION['info'] = "";
    $otp_code = mysqli_real_escape_string($conn, $_POST['otp']);
    $check_code = "SELECT * FROM admin_users WHERE token = '$otp_code'";
    $code_res = mysqli_query($conn, $check_code);
    if(mysqli_num_rows($code_res) > 0){
        $fetch_data = mysqli_fetch_assoc($code_res);
        $email = $fetch_data['email'];
        $_SESSION['email'] = $email;
        $info = "Please create a new password that you don't use on any other site.";
        $_SESSION['info'] = $info;
        header('location: new-password.php');
        exit();
    }else{
        $showError = "You've entered incorrect code!";
    }
}



 //if user click change password button
 if(isset($_POST['changePassword'])){
    $_SESSION['info'] = "";
    $password = mysqli_real_escape_string($conn, md5($_POST['password']));
    $cpassword = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
    if($password !== $cpassword){
        $showError = "Confirm password not matched!";
    }else{
        $code = 0;
        $email = $_SESSION['user_email']; //getting this email using session
        // $encpass = password_hash($password, PASSWORD_BCRYPT);
        $update_pass = "UPDATE admin_users SET token ='$code', password ='$password' WHERE user_email = '$email'";
        $run_query = mysqli_query($conn, $update_pass);
        if($run_query){
            $info = "Your password changed. Now you can login with your new password.";
            $_SESSION['info'] = $info;
            header('Location: changed-password.php');
        }else{
            $showError = "Failed to change your password!";
        }
    }
}


 //if login now button click
 if(isset($_POST['loginNow'])){
    header('Location: login.php');
}

?>

<?php
include('layout/admin_header.php');
?>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
            <?php
                include('layout/sidbar.php');
                ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Contact Us</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="<?php echo $adminurl; ?>index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Contact Us</li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-body">
                                DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the
                                <!-- <a href="#">official DataTables documentation</a> -->
                                .
                            </div>
                        </div>
                       
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Contact Us Details
                            </div>
                            <div class="card-body table-responsive">
                            <table class="table table-bordered" id="datatablesSimple">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Upload File</th>
      <th scope="col">Title</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Subject</th>
      <th scope="col">Message</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>

    <?php
    include('config.php');   

    $selectquery = " select * from contactus ";

    // inserted data showing in table
    $query = mysqli_query($conn, $selectquery);

    $nums = mysqli_num_rows($query);

    // $res = mysqli_fetch_array($query);

    // loop increase the table
    while($res = mysqli_fetch_array($query)){
      // echo $res['Name'] . "<br>";


?>

      <tr>
      <td><?php echo $res['Id']; ?></td>
       <td><img class="img-table" style="width: 100px; height:auto;" src="<?php echo $adminurl; ?>/<?php echo $res['file_name']; ?>" alt="images"></td>
       <td><?php echo $res['Title']; ?></td>
      <td><?php echo $res['Name']; ?></td>
      <td><?php echo $res['Email']; ?></td>
      <td><?php echo $res['Subject']; ?></td>
      <td><?php echo $res['Message']; ?></td>
      <td align="center"><a href="delete.php?userid=<?php echo $res['Id']; ?>" data-bs-toggle="tooltip" title="Delete"> <i class="fa fa-trash"></i> </a> </td>
    </tr>

<?php
}
 ?>


    

  </tbody>
</table>
                            </div>
                        </div>

                    </div>
                </main>
                
<?php
include('layout/admin_footer.php');
?>
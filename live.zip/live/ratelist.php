
<?php
include('layout/header.php');

?>
<style>
   .table  h4, h3, h2 {font-weight:normal; font-size:16px !important}
   .table  h1 {font-weight:normal; font-size:25px !important}
   .table  h2 {font-weight:normal; font-size:20px !important}
    </style>

<div class="page-heading"><h1>Rate List</h1></div>   
<main id="main" class="site-main mt-0">
       


  <section class="text-center">
    <div class="container">
        <!-- <div class="heading"><span class="subtitle">Need more help?</span>
            <h2>Have a <span>Question?</span></h2><span class="dot1"></span><span class="dot1"></span><span class="dot1"></span><span class="dot"></span>
        </div> -->



                            

                          <div class="table-responsive">
                          <table class="table table-bordered">
                          <tbody><tr>
                           <td colspan="3" style="background:#f5f5f5;"><h2><font color="#ed1d24"><center>Printing Rates on 19 x 25</center></font></h2></td>
                          </tr>
                          <tr>
                          <td style="width:37.5%"><h3><font color="#ed1d24">Qty.</font></h3></td> <td style="width:25%"><h3>Type</h3></td> <td style="width:37.5%"><h3>Price</h3></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">1000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>1700/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Work &amp; Turn</h4></td> <td><h4>1800/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Pase Ki Lot</h4></td> <td><h4>1700/-</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">2000</font></h4></td> <td><h4>........</h4></td> <td><h4>1700+500</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">3000</font></h4></td> <td><h4>........</h4></td> <td><h4>1700+500+500</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">4000 or Above</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>1500+400 Next</h4>(1700+1400/-)</td>
                          </tr>
                          
                          </tbody></table>
                          
                          </div>

                          <div class="table-responsive">
                          <table class="table table-bordered">
                          <tbody><tr>
                            <td colspan="3" style="background:#f5f5f5;"><h2><font color="#ed1d24"><center>Printing Rates on 20 x 30</center></font></h2></td>
                          </tr>
                          <tr>
                          <td style="width:37.5%"><h3><font color="#ed1d24">Qty.</font></h3></td> <td style="width:25%"><h3>Type</h3></td> <td style="width:37.5%"><h3>Price</h3></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">1000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>2400/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Work &amp; Turn</h4></td> <td><h4>2500/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Pase Ki Lot</h4></td> <td><h4>2500/-</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">2000 to 9000</font></h4></td> <td><h4>........</h4></td> <td><h4>2400-700 Next</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">10000</font></h4></td> <td><h4>........</h4></td> <td><h4>1300+6500/-</h4>Plate Cost+700 Per Thousand</td>
                          </tr>
                          
                            <tr style="opacity:0;">
                          <td><h4><font color="#ed1d24">2000 to 9000</font></h4></td> <td><h4>........</h4></td> <td><h4>2400-800 Next</h4></td>
                          </tr>
                          
                          
                          </tbody></table>
                          
                          </div>
                         
                           <div class="table-responsive">
                          <table class="table table-bordered">
                          <tbody><tr>
                            <td colspan="3" style="background:#f5f5f5;"><h2><font color="#ed1d24"><center>Printing Rates on 23 x 36</center></font></h2></td>
                          </tr>
                          <tr>
                          <td style="width:37.5%"><h3><font color="#ed1d24">Qty.</font></h3></td> <td style="width:25%"><h3>Type</h3></td> <td style="width:37.5%"><h3>Price</h3></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">1000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>3400/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Work &amp; Turn</h4></td> <td><h4>3600/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Pase Ki Lot</h4></td> <td><h4>3600/-</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">2000 to 5000</font></h4></td> <td><h4>........</h4></td> <td><h4>+1400/- Per Th.</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">6000 to 10000</font></h4></td> <td><h4>........</h4></td> <td><h4>3400+800/- Per Th.</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">20000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>2400+14000</h4>Plate Cost+700 Per Thousand)</td>
                          </tr>
                          
                          <tr>
                          <td><h4><font color="#ed1d24">30000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>2400+18000</h4>Plate Cost+600 Per Thousand</td>
                          </tr>
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                          <tbody><tr>
                            <td colspan="3" style="background:#f5f5f5;"><h2><font color="#ed1d24"><center>Printing Rates on 25 x 36</center></font></h2></td>
                          </tr>
                          <tr>
                         <td style="width:37.5%"><h3><font color="#ed1d24">Qty.</font></h3></td> <td style="width:25%"><h3>Type</h3></td> <td style="width:37.5%"><h3>Price</h3></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">1000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>3500/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Work &amp; Turn</h4></td> <td><h4>4000/-</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">500</font></h4></td> <td><h4>Pase Ki Lot</h4></td> <td><h4>4000/-</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">2000 to 5000</font></h4></td> <td><h4>........</h4></td> <td><h4>+1500/- Per Th.</h4></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">6000 to 10000</font></h4></td> <td><h4>........</h4></td> <td><h4>3600+800/- Per Th.</h4></td>
                          </tr>
                          
                            <tr>
                          <td id="visit"><h4><font color="#ed1d24">20000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>2400+14000</h4>Plate Cost+700 Per Thousand</td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">30000</font></h4></td> <td><h4>Single Slide</h4></td> <td><h4>2400+18000</h4>Plate Cost+600 Per Thousand</td>
                          </tr>
                          
                          
                          </tbody></table>
                          
                          </div>
                          
                            
          
                          <table class="table table-bordered">
                          <tbody><tr>
                          <td style="background:#000000;"><h1 class="mb-0 pb-0"><font color="#FFFFFF">Visiting Card Rate List</font></h1></td>
                          </tr>
                          
                          </tbody></table>
                          
                                     
                          <div class="table-responsive">
                          <table class="table table-bordered">
                         <tbody><tr>
                           <td style="width:40%"><h3><font color="#ed1d24">Particulars</font></h3></td> <td style="width:20%"><h3>Rate</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3>Urgent</h3></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">Light SBS</font></h4><h6><font color="#ed1d24">With Lamination</font></h6></td> <td><h4>150/-</h4></td> <td><h4>3 Days</h4></td><td><h4>20/-</h4><h6>(Next Day)</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Warnish</font></h4><h6><font color="#ed1d24">Without Lamination</font></h6></td> <td><h4>148/-</h4></td> <td><h4>3-4 Days</h4></td><td><h4>20/-</h4><h6>2 Days</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Art Lamination</font></h4><h6><font color="#ed1d24">With Lamination</font></h6></td> <td><h4>160/-</h4></td> <td><h4>3-4 Days</h4></td><td><h4>20/-</h4><h6>2 Days</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">SBS</font></h4><h6><font color="#ed1d24">With Lamination</font></h6></td> <td><h4>170/-</h4></td> <td><h4>3-4 Days</h4></td><td><h4>20/-</h4><h6>2 Days</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">HL<font size="2px">(Heavy Lamination)</font></font></h4><h6><font color="#ed1d24"><font size="2px">With Lamination</font></font></h6></td> <td><h4>200/-</h4></td> <td><h4>2-3 Days</h4></td><td><h4>10/-</h4><h6>2 Days</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">BHL<font size="2px">(Bada Heavy Lamination)</font></font></h4><h6><font color="#ed1d24">With Lamination</font></h6></td> <td><h4>210/-</h4></td> <td><h4>3-4 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Both Side</font></h4><h6><font color="#ed1d24">BS Lamination</font></h6></td> <td><h4>210/-</h4></td> <td><h4>3-4 Days</h4></td><td><h4>30/-</h4><h6>3 Days</h6></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Big Bothside</font></h4><h6><font color="#ed1d24">BS Lamination</font></h6></td> <td><h4>210/-</h4></td> <td><h4>5-6 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                         <tbody><tr>
                           <td style="width:40%"><h3><font color="#ed1d24">Particulars</font></h3></td> <td style="width:20%"><h3>Rate</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3>Urgent</h3></td>
                          </tr>
                          
                           <tr>
                          <td><h4><font color="#ed1d24">Matt</font></h4><h6><font color="#ed1d24">Without Lamination</font></h6></td> <td><h4>270/-</h4></td> <td><h4>5-6 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Texture Matt</font></h4><h6><font color="#ed1d24">With Texture</font></h6></td> <td><h4>310/-</h4></td> <td><h4>5-6 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Leather Tex. Matt</font></h4><h6><font color="#ed1d24">With Texture</font></h6></td> <td><h4>315/-</h4></td> <td><h4>5-6 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">UV Coating</font></h4><h6><font color="#ed1d24">Single side Spot UV</font></h6></td> <td><h4>560/-</h4></td> <td><h4>12-15 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                          
                          
                             <tr style="height:64px;">
                          <td><h4><font color="#ed1d24">SYNTHETIC<br><font size="2px">Single Side Thermel Larn.</font></font></h4></td> <td><h4>470/-</h4></td> <td><h4>7 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td><h4><font color="#ed1d24">Rangila Matt</font></h4><h6><font color="#ed1d24">BS Thermel Matt Larn.</font></h6></td> <td><h4>430/-</h4></td> <td><h4>7 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr>
                          <td id="other"><h4><font color="#ed1d24">Chamkila UV</font></h4><h6><font color="#ed1d24">BS Thermal Matt Larn.+Spot UV</font></h6></td> <td><h4>550/-</h4></td> <td><h4>18-20 Days</h4></td><td><h4>No Urgent Service</h4></td>
                          </tr>
                          
                             <tr style="opacity:0;">
                          <td><h4><font color="#ed1d24">HL</font></h4><h6><font color="#ed1d24">With Lamination</font></h6></td> <td><h4>470/-</h4></td> <td><h4>18-20 Days</h4></td><td>&gt;<h6>3 Days</h6></td>
                          </tr>
                          
                          
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                    
                          <table class="table table-bordered">
                          <tbody><tr>
                          <td style="background:#000000;"><h1 class="mb-0 pb-0"><font color="#FFFFFF">Other Product's Details</font></h1></td>
                          </tr>
                          
                          </tbody></table>
                          
                          <div class="table-responsive">
                          <table class="table table-bordered">
                           <tbody><tr>
                               <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Sticker With Bopp Lamination</font></h3></td>
                          </tr>
                          
                                        
                    <tr>
                           <td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>4 Days</h4></td> <td><h4 class="colors">7x4.75</h4></td><td><h4>900/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">7x9.5</h4></td><td><h4>1700/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x9.5</h4></td><td><h4>3150/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x19</h4></td><td><h4>6500/-</h4></td>
                          </tr>  
                          
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                                         <tbody><tr>
                          <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Sticker(Hard Gumming Without Lamination)</font></h3></td>
                          </tr>
                          <tr><td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>7 Days</h4></td> <td><h4 class="colors">7x4.75</h4></td><td><h4>1150/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">7x9.5</h4></td><td><h4>2100/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x9.5</h4></td><td><h4>3800/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x19</h4></td><td><h4>7750/-</h4></td>
                          </tr> 
                         
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                          
                          
                          <div class="table-responsive">
                          <table class="table table-bordered">
                           <tbody><tr>
                            <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Sticker Plastic Vinyle</font></h3></td>
                          </tr>
                          
                                        
                    <tr>
                           <td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>7 Days</h4></td> <td><h4 class="colors">7x4.75</h4></td><td><h4>1150/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">7x9.5</h4></td><td><h4>2100/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x9.5</h4></td><td><h4>4200/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4>3-4 Days</h4></td> <td><h4 class="colors">14x19</h4></td><td><h4>8000/-</h4></td>
                          </tr>  
                          
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                                        
                                         <tbody><tr>
                            <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Sticker PVC Transparent</font></h3></td>
                          </tr>
                          <tr><td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>15 Days</h4></td> <td><h4 class="colors">7x4.75</h4></td><td><h4>2400/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">7x9.5</h4></td><td><h4>4200/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x9.5</h4></td><td><h4>8000/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x19</h4></td><td><h4>18200/-</h4></td>
                          </tr> 
                         
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                          
                          <div class="table-responsive">
                          <table class="table table-bordered">
                           <tbody><tr>
                             <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Sticker Silver Foil</font></h3></td>
                          </tr>
                          
                                        
                    <tr>
                           <td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>10 Days</h4></td> <td><h4 class="colors">7x4.75</h4></td><td><h4>2350/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">7x9.5</h4></td><td><h4>4300/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x9.5</h4></td><td><h4>8200/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4></h4></td> <td><h4></h4></td> <td><h4></h4></td> <td><h4 class="colors">14x19</h4></td><td><h4>17600/-</h4></td>
                          </tr>  
                           <tr style="opacity:0;">
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>7-10 Days</h4></td> <td><h4>5.5x8.5</h4></td><td><h4>850/-</h4></td>
                          </tr> 
                          
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                                        
                                         <tbody><tr>
                          <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Pamphlet 70 GSM Art (Single Side)</font></h3></td>
                          </tr>
                          <tr><td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4></h4></td> <td><h4>2000</h4></td> <td><h4>7-10 Days</h4></td> <td><h4 class="colors">8.25x11</h4></td><td><h4>1900/-</h4></td>
                          </tr>  
                          
                                        <tr>
                         <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Label Mirror Coat 80 GSM</font></h3></td>
                          </tr>
                          <tr><td style="width:20%"><h3>Particulars</h3></td> <td style="width:20%"><h3>Qty.</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3 class="colors">Sq. Inch.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr style="height:46px;">
                           <td><h4></h4></td> <td><h4>1000</h4></td> <td><h4>12-15 Days</h4></td> <td><h4 class="colors">5.5x8.5</h4></td><td><h4>850/-</h4></td>
                          </tr>  
                          
                        
                         
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                          <div class="table-responsive">
                          <table class="table table-bordered">
                           <tbody><tr>
                             <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Brouchers / Leaflet Bothside Multicolor</font></h3></td>
                          </tr>
                          
                                        
                    <tr>
                           <td style="width:20%"><h3><font color="#ed1d24">Particulars</font></h3></td> <td style="width:20%"><h3></h3></td> <td style="width:20%"><h3>Size</h3></td> <td style="width:20%"><h3>Qty.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4><font color="#ed1d24">90 Gsm. Art Paper</font></h4></td> <td><h4>Minimum 2000 pcs.</h4></td> <td><h4>8.25x11</h4></td> <td><h4>1200</h4></td><td><h4>950/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">130 Gsm. Art Paper</font></h4></td><td rowspan="3"><h4></h4></td> <td><h4>8.25x11</h4></td> <td><h4>1250</h4></td><td><h4>1450/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">170 Gsm. Art Paper</font></h4></td> <td><h4>8.5x12.25</h4></td> <td><h4>1000</h4></td><td><h4>2150/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">300 Gsm. Art Card</font></h4></td> <td><h4>8.2x11</h4></td> <td><h4>1000</h4></td><td><h4>2900/-</h4></td>
                          </tr>  
                          
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                                        
                                         <tbody><tr>
                             <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Letter Head</font></h3></td>
                          </tr>
                          <tr>
                          <td style="width:20%"><h3><font color="#ed1d24">Particulars</font></h3></td> <td style="width:20%"><h3>size</h3></td> <td style="width:20%"><h3>Delivery</h3></td> <td style="width:20%"><h3>Qty.</h3></td><td style="width:20%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4><font color="#ed1d24">110 Gsm. Matt Paper</font></h4></td> <td><h4>8.25x11</h4></td> <td><h4>3 Days</h4></td> <td><h4>1200</h4></td><td><h4>850/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">80/90 Gsm. Sunshine</font></h4></td> <td><h4>8.5x11.25</h4></td> <td><h4>6-7 Days</h4></td> <td><h4>1200</h4></td><td><h4>900/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">100 Gsm Do Paper</font></h4></td> <td><h4>8.25x11.75</h4></td> <td><h4>1 Week</h4></td> <td><h4>1200</h4></td><td><h4>1075/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">80 Gsm Exe. Bond</font></h4></td> <td><h4>8.25x11.35</h4></td> <td><h4>1 Week</h4></td> <td><h4>1200</h4></td><td><h4>1100/-</h4></td>
                          </tr> 
                         
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                          
                          <div class="table-responsive">
                          <table class="table table-bordered">
                           <tbody><tr>
                           <td colspan="5" style="background:#f5f5f5;"><h3><font color="#ed1d24">Envelops</font></h3></td>
                          </tr>
                          
                                        
                    <tr>
                           <td style="width:45%"><h3><font color="#ed1d24">Particulars</font></h3></td>  <td style="width:15%"><h3>Size</h3></td><td style="width:20%"><h3>Delivery</h3></td> <td style="width:15%"><h3>Qty.</h3></td> <td style="width:15%"><h3>Price</h3></td>
                          </tr>
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 110 Gsm Matt</font></h4></td> <td><h4>9.75x4</h4></td> <td><h4>5-6 Days</h4></td> <td><h4>1000</h4></td><td><h4>1250/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 90 Gsm Sunshine</font></h4></td> <td><h4>9.75x4</h4></td> <td><h4>1 Week</h4></td> <td><h4>1000</h4></td><td><h4>1400/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 90 Gsm Sunshine</font></h4></td> <td><h4>9.5x4.25</h4></td> <td><h4>1 Week</h4></td> <td><h4>1000</h4></td><td><h4>1400/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 90 Gsm Sunshine</font></h4><h6><font color="#ed1d24">(Window With Lamination)</font></h6></td> <td><h4>9.5x4.25</h4></td> <td><h4>1 Week</h4></td> <td><h4>1000</h4></td><td><h4>1600/-</h4></td>
                          </tr>  
                          
                          
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 120 Gsm Sunshine</font></h4><h6><font color="#ed1d24">(Center Pasting)</font></h6></td> <td><h4>9.75x12</h4></td> <td><h4>1 Week</h4></td> <td><h4>1000</h4></td><td><h4>4100/-</h4></td>
                          </tr>  
                          
                           <tr>
                           <td><h4><font color="#ed1d24">Envelops on 120 Gsm Sunshine</font></h4><h6><font color="#ed1d24">(Side Pasting)</font></h6></td> <td><h4>9.75x12</h4></td> <td><h4>1 Week</h4></td> <td><h4>1000</h4></td><td><h4>5000/-</h4></td>
                          </tr>  
                          
                         
                  
                
                          
                          </tbody></table>
                          
                          </div>
                          <div class="table-responsive">
                          <table class="table table-bordered">
                                        
                                         <tbody><tr>
                           <td colspan="4" style="background:#f5f5f5;"><h3><font color="#ed1d24">Posters</font></h3></td>
                          </tr>
                     <tr>
                           <td style="width:50%"><h3><font color="#ed1d24">Particulars</font></h3></td>  <td style="width:20%"><h3>Delivery</h3></td><td style="width:15%"><h3>Qty.</h3></td> <td style="width:15%"><h3>Price</h3></td>
                          </tr>
                           <tr height="60px;">
                           <td><h4><font color="#ed1d24">Maphletho (58 Gsm.)</font></h4></td> <td><h4>18x23</h4></td> <td><h4>10000</h4></td> <td><h4>2800/-</h4></td>
                          </tr>  
                          
                           <tr height="60px;">
                           <td><h4><font color="#ed1d24">Maphletho (70 Gsm.)</font></h4></td> <td><h4>18-23</h4></td> <td><h4>1000</h4></td> <td><h4>3200/-</h4></td>
                          </tr>  
                          
                           <tr height="60px;">
                           <td><h4><font color="#ed1d24">Art Paper (70 Gsm.)</font></h4></td> <td><h4>18-23</h4></td> <td><h4>1000</h4></td> <td><h4>3150/-</h4></td>
                          </tr>  
                          
                           <tr height="60px;">
                           <td><h4><font color="#ed1d24">Art Paper (90 Gsm.)</font></h4></td> <td><h4>18-23</h4></td> <td><h4>1000</h4></td> <td><h4>3450/-</h4></td>
                          </tr>  
                          
                          
                           <tr height="50px;">
                           <td><h4><font color="#ed1d24">Art Paper (90 Gsm.)</font></h4><h6><font color="#ed1d24">(Work &amp; Turn)</font></h6></td> <td><h4>18-23</h4></td> <td><h4>1000</h4></td> <td><h4>4150/-</h4></td>
                          </tr>  
                          
                           <tr height="60px;">
                           <td><h4><font color="#ed1d24">Cromo (90 Gsm.)</font></h4></td> <td><h4>18-23</h4></td> <td><h4>1000</h4></td> <td><h4>3500/-</h4></td>
                          </tr>  
                          
                          
                            <tr height="60px;">
                           <td><h4><font color="#ed1d24">Cromo (90 Gsm.)</font></h4></td> <td><h4>20x28.5</h4></td> <td><h4>1000</h4></td> <td><h4>4500/-</h4></td>
                          </tr>  
                          
                  
                
                          
                          </tbody></table>
                        
                          
                          </div>
                          
                        


</div>

</main>

<?php
include('layout/footer.php');

?>






<?php
session_start();
session_unset();
$_SESSION = array(); 
unset($_SESSION['fname'],$_SESSION['user_email']);
session_destroy();
// header('location://therainbowprint.com/admin/login.php');
?>

<script type="text/javascript">
    location.replace("//therainbowprint.com/admin/login.php");
 </script> 

 <?php
exit;

?>

    
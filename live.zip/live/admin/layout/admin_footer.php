<footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
      

<script src="<?php echo $adminurl; ?>/assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo $adminurl; ?>/assets/js/scripts.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo $adminurl; ?>/assets/js/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo $adminurl; ?>/assets/demo/chart-area-demo.js"></script>
        <script src="<?php echo $adminurl; ?>/assets/demo/chart-bar-demo.js"></script> -->
        <script src="<?php echo $adminurl; ?>/assets/js/simple-datatables.min.js"></script>
        <script src="<?php echo $adminurl; ?>/assets/js/datatables-simple-demo.js"></script>


 
    </body>
</html>
